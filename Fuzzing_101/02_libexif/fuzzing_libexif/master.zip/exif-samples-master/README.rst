============
Exif Samples
============

Sample images for testing Exif metadata retrieval.

Adding Images
=============

Please do!

User-contributed images will be released under the **Attribution-ShareAlike 4.0 International** license.
